import styles from "./QMProductComplaintsCount.module.css";

const QMProductComplaintsCount = () => {
  return (
    <div className={styles.qmProductComplaintsCount}>
      <div className={styles.nestedGrids} />
      <div className={styles.navigationBar}>
        <div className={styles.sidecontainerbackground}>
          <div className={styles.bkdOverlay} />
          <div className={styles.roster}>
            <div className={styles.backgroundFill} />
            <div className={styles.linkItem}>
              <img className={styles.vectorIcon} alt="" src="/vector.svg" />
              <div className={styles.xsmallText}>Logout</div>
            </div>
          </div>
        </div>
        <div className={styles.home}>
          <div className={styles.backgroundFill1} />
          <div className={styles.linkItem1}>
            <img
              className={styles.zsIconHomeFill}
              alt=""
              src="/zsiconhomefill.svg"
            />
            <div className={styles.xsmallText1}>Home</div>
          </div>
        </div>
        <div className={styles.roster1}>
          <div className={styles.backgroundFill2} />
          <div className={styles.linkItem2}>
            <img className={styles.unionIcon} alt="" src="/union.svg" />
            <div className={styles.xsmallText}>
              <p className={styles.quality}>Quality</p>
              <p className={styles.quality}>Monitoring</p>
            </div>
          </div>
        </div>
        <div className={styles.roster2}>
          <div className={styles.backgroundFill3} />
          <div className={styles.linkItem2}>
            <img className={styles.unionIcon} alt="" src="/group@2x.png" />
            <div className={styles.xsmallText}>Batch Deep Dive</div>
          </div>
        </div>
        <div className={styles.roster3}>
          <div className={styles.backgroundFill3} />
          <div className={styles.linkItem2}>
            <img className={styles.vectorIcon} alt="" src="/group.svg" />
            <div className={styles.xsmallText}>Product Compaints</div>
          </div>
        </div>
        <div className={styles.roster4}>
          <div className={styles.backgroundFill3} />
          <div className={styles.linkItem}>
            <img className={styles.vectorIcon} alt="" src="/vector.svg" />
            <div className={styles.xsmallText}>Deviations</div>
          </div>
        </div>
        <div className={styles.roster5}>
          <div className={styles.backgroundFill3} />
          <div className={styles.linkItem6}>
            <img className={styles.vectorIcon} alt="" src="/vector.svg" />
            <div className={styles.xsmallText}>CAPA</div>
          </div>
        </div>
        <div className={styles.roster6}>
          <div className={styles.backgroundFill3} />
          <div className={styles.linkItem}>
            <img className={styles.groupIcon2} alt="" src="/group.svg" />
            <div className={styles.xsmallText}>Change Control</div>
          </div>
        </div>
        <img
          className={styles.logozsfullColornavIcon}
          alt=""
          src="/logozsfullcolornav.svg"
        />
      </div>
      <div className={styles.breadcrumb}>
        <div className={styles.stItem}>
          <div className={styles.stItemLabel}>Home</div>
        </div>
        <div className={styles.componentsseparator}>
          <div className={styles.separator}>/</div>
        </div>
        <div className={styles.stItem}>
          <div className={styles.stItemLabel}>All Apps</div>
        </div>
        <div className={styles.componentsseparator}>
          <div className={styles.separator}>/</div>
        </div>
        <div className={styles.stItem}>
          <div className={styles.stItemLabel}>Batch Traceability</div>
        </div>
        <div className={styles.componentsseparator}>
          <div className={styles.separator}>/</div>
        </div>
        <div className={styles.lastItem}>
          <div className={styles.stItemLabel}>Quality Monitoring</div>
        </div>
      </div>
      <div className={styles.headingLeft}>
        <img
          className={styles.zsIconHomeFill}
          alt=""
          src="/zsiconarrowleft.svg"
        />
        <div className={styles.wrapper}>
          <div className={styles.qualityMonitoring}>Quality Monitoring</div>
          <div className={styles.thisIsA}>This is a subtitle</div>
        </div>
      </div>
      <div className={styles.summary}>
        <div className={styles.filterMenu} />
        <div className={styles.bgParent}>
          <img className={styles.bgIcon} alt="" src="/bg.svg" />
          <div className={styles.summary1}>
            <div className={styles.overallComplaints}>Overall Complaints</div>
            <div className={styles.parent}>
              <div className={styles.div}>87</div>
              <div className={styles.days}>30 Days</div>
            </div>
            <div className={styles.daysParent}>
              <div className={styles.year}>90 Days</div>
              <div className={styles.div1}>210</div>
            </div>
            <div className={styles.yearParent}>
              <div className={styles.year}>1 Year</div>
              <div className={styles.div1}>430</div>
            </div>
            <div className={styles.delayedComplaintsClosureParent}>
              <div className={styles.delayedComplaintsClosure}>
                Delayed Complaints Closure
              </div>
              <div className={styles.group}>
                <div className={styles.div}>4%</div>
                <div className={styles.days}>30 Days</div>
              </div>
              <div className={styles.daysGroup}>
                <div className={styles.year}>90 Days</div>
                <div className={styles.div1}>7%</div>
              </div>
              <div className={styles.yearGroup}>
                <div className={styles.year}>1 Year</div>
                <div className={styles.div1}>9%</div>
              </div>
            </div>
            <div className={styles.openComplaintsParent}>
              <div className={styles.openComplaints}>Open Complaints</div>
              <div className={styles.container}>
                <div className={styles.div6}>9%</div>
                <div className={styles.days}>Past Due Date</div>
              </div>
            </div>
            <div className={styles.text}>
              <div className={styles.textbodyNormal}>
                <div className={styles.bodyNormalSemibold}>Summary</div>
              </div>
            </div>
          </div>
          <div className={styles.calendar}>
            <div className={styles.text1}>
              <div className={styles.textbodyNormal}>
                <div className={styles.bodyNormalSemibold}>Year</div>
              </div>
            </div>
            <div className={styles.outlinesmallselected}>
              <div className={styles.outlinesmallselected1}>
                <div className={styles.mastersmall}>
                  <div className={styles.masterdropdowntrigger}>
                    <img
                      className={styles.iconRight}
                      alt=""
                      src="/iconright.svg"
                    />
                    <div className={styles.bodyNormalSemibold}>All</div>
                    <img
                      className={styles.zsIconCaratDown}
                      alt=""
                      src="/zsiconcaratdown.svg"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className={styles.acitivityParent}>
            <div className={styles.acitivity}>
              <div className={styles.lastRefreshed2Container}>
                <span>{`Last refreshed: `}</span>
                <span className={styles.daysAgoSep}>
                  2 days ago (Sep 9th, 2022)
                </span>
              </div>
              <div className={styles.lastRefreshedYesterdayContainer}>
                <span>{`Last refreshed: `}</span>
                <span className={styles.daysAgoSep}>
                  Yesterday (Sep 9th, 2022)
                </span>
              </div>
              <div className={styles.lastRefreshedTodayContainer}>
                <span>{`Last refreshed: `}</span>
                <span className={styles.daysAgoSep}>Today (Sep 9th, 2022)</span>
              </div>
              <div className={styles.lastRefreshed14Container}>
                <span>{`Last refreshed: `}</span>
                <span className={styles.daysAgoSep}>
                  14 days ago (Sep 9th, 2022)
                </span>
              </div>
            </div>
            <div className={styles.radiolabels}>
              <div className={styles.radioselected}>
                <img className={styles.vectorIcon} alt="" src="/radio.svg" />
                <div className={styles.stItemLabel}>
                  Product Complaints Count
                </div>
              </div>
              <div className={styles.radio}>
                <img className={styles.vectorIcon} alt="" src="/radio.svg" />
                <div className={styles.stItemLabel}>CAPA</div>
              </div>
              <div className={styles.radio1}>
                <img className={styles.vectorIcon} alt="" src="/radio.svg" />
                <div className={styles.stItemLabel}>Change Control Count</div>
              </div>
              <div className={styles.radio2}>
                <img className={styles.vectorIcon} alt="" src="/radio.svg" />
                <div className={styles.stItemLabel}>Deviation Count</div>
              </div>
            </div>
          </div>
          <div className={styles.groupChild} />
        </div>
      </div>
      <div className={styles.charts}>
        <div className={styles.charts1}>
          <div className={styles.resolutionStatus}>
            <div className={styles.header}>
              <b className={styles.title}>Resolution Status</b>
              <div className={styles.descriptionText}>
                Distribution of resolution status of the total issues based on
                the year and selected parameter Product Complaints
              </div>
            </div>
            <div className={styles.menubuttonLine}>
              <div className={styles.groupsolidsmall}>
                <div className={styles.solidsmallleftactivedefaul}>
                  <div className={styles.mastersolidsmallleft}>
                    <div className={styles.filter}>Tab 1</div>
                  </div>
                </div>
                <div className={styles.stItem}>
                  <div className={styles.mastersolidsmallmiddle}>
                    <div className={styles.filter}>Tab 2</div>
                  </div>
                </div>
                <div className={styles.stItem}>
                  <div className={styles.mastersolidsmallright}>
                    <div className={styles.filter}>Tab 3</div>
                  </div>
                </div>
              </div>
              <div className={styles.actionRow}>
                <div className={styles.mediumoutlineprimaryiconLe}>
                  <div className={styles.mastermediumtext}>
                    <div className={styles.content}>
                      <img
                        className={styles.zsIconHomeFill}
                        alt=""
                        src="/icon-container.svg"
                      />
                      <div className={styles.filter}>Filter</div>
                      <img
                        className={styles.iconContainer1}
                        alt=""
                        src="/icon-container.svg"
                      />
                    </div>
                  </div>
                </div>
                <div className={styles.smalloutlineprimaryiconOnl}>
                  <div className={styles.mastersmallicon}>
                    <img
                      className={styles.zsIconCaratDown}
                      alt=""
                      src="/zsiconfilter.svg"
                    />
                  </div>
                </div>
                <div className={styles.smalloutlineprimaryiconOnl}>
                  <div className={styles.mastersmallicon}>
                    <img
                      className={styles.zsIconCaratDown}
                      alt=""
                      src="/zsiconmore.svg"
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className={styles.delayed2535Parent}>
              <div className={styles.delayed2535Container}>
                <p className={styles.delayed}>Delayed</p>
                <p className={styles.p}>
                  <span>
                    <b className={styles.b}>25%</b>
                    <span className={styles.span}> (35)</span>
                  </span>
                </p>
              </div>
              <div className={styles.open2535Container}>
                <p className={styles.delayed}>Open</p>
                <p className={styles.p}>
                  <span>
                    <b className={styles.b}>25%</b>
                    <span className={styles.span}> (35)</span>
                  </span>
                </p>
              </div>
              <div className={styles.closed3365Container}>
                <p className={styles.delayed}>Closed</p>
                <p className={styles.p}>
                  <span>
                    <b className={styles.b}>33%</b>
                    <span className={styles.span}> (65)</span>
                  </span>
                </p>
              </div>
              <img
                className={styles.groupItem}
                alt=""
                src="/group-48098917.svg"
              />
            </div>
            <div className={styles.totalNumber200Container}>
              <p className={styles.delayed}>Total Number</p>
              <p className={styles.p3}>
                <b className={styles.b3}>200</b>
              </p>
            </div>
          </div>
          <div className={styles.complaintDistribution}>
            <div className={styles.header1}>
              <b className={styles.title1}>Complaint Count Trendline</b>
              <div className={styles.descriptionText1}>
                Comparison of counts for the selected parameter Product
                Complaints across selected years
              </div>
            </div>
            <div className={styles.footer}>
              <div className={styles.legend}>
                <div className={styles.r1}>
                  <div className={styles.legendItem}>
                    <div className={styles.legendItemChild} />
                    <div className={styles.div7}>2022</div>
                  </div>
                  <div className={styles.legendItem}>
                    <div className={styles.legendItemItem} />
                    <div className={styles.div7}>2021</div>
                  </div>
                </div>
              </div>
            </div>
            <div className={styles.noBorderxsmallselected}>
              <div className={styles.outlinesmallselected1}>
                <div className={styles.noBorderxsmall}>
                  <div className={styles.masterdropdowntrigger1}>
                    <img
                      className={styles.iconRight1}
                      alt=""
                      src="/iconright.svg"
                    />
                    <div className={styles.bodyNormalSemibold}>2021</div>
                    <img
                      className={styles.zsIconCaratDown1}
                      alt=""
                      src="/zsiconcaratdown.svg"
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className={styles.xAxisValuesParent}>
              <div className={styles.xAxisValues}>
                <div className={styles.series1}>
                  <div className={styles.bodyNormalSemibold}>Jan</div>
                </div>
                <div className={styles.series1}>
                  <div className={styles.bodyNormalSemibold}>Feb</div>
                </div>
                <div className={styles.series1}>
                  <div className={styles.bodyNormalSemibold}>Mar</div>
                </div>
                <div className={styles.series1}>
                  <div className={styles.bodyNormalSemibold}>Apr</div>
                </div>
                <div className={styles.series1}>
                  <div className={styles.bodyNormalSemibold}>May</div>
                </div>
                <div className={styles.series1}>
                  <div className={styles.bodyNormalSemibold}>Jun</div>
                </div>
                <div className={styles.series1}>
                  <div className={styles.bodyNormalSemibold}>Jul</div>
                </div>
                <div className={styles.series1}>
                  <div className={styles.bodyNormalSemibold}>Aug</div>
                </div>
                <div className={styles.series1}>
                  <div className={styles.bodyNormalSemibold}>Sep</div>
                </div>
                <div className={styles.series1}>
                  <div className={styles.bodyNormalSemibold}>Oct</div>
                </div>
                <div className={styles.series1}>
                  <div className={styles.bodyNormalSemibold}>Nov</div>
                </div>
                <div className={styles.series1}>
                  <div className={styles.bodyNormalSemibold}>Dec</div>
                </div>
                <div className={styles.series8}>
                  <div className={styles.bodyNormalSemibold}>Value</div>
                </div>
                <div className={styles.series8}>
                  <div className={styles.bodyNormalSemibold}>Value</div>
                </div>
                <div className={styles.series8}>
                  <div className={styles.bodyNormalSemibold}>Value</div>
                </div>
                <div className={styles.series8}>
                  <div className={styles.bodyNormalSemibold}>Value</div>
                </div>
                <div className={styles.series8}>
                  <div className={styles.bodyNormalSemibold}>Value</div>
                </div>
              </div>
              <div className={styles.horizontal1light}>
                <div className={styles.divider1Px} />
              </div>
              <div className={styles.horizontal1mediumLight}>
                <div className={styles.dividerhorizontal1medium}>
                  <div className={styles.divider1Px1} />
                </div>
              </div>
              <div className={styles.horizontal1light1}>
                <div className={styles.divider1Px} />
              </div>
              <div className={styles.horizontal1light2}>
                <div className={styles.divider1Px} />
              </div>
              <div className={styles.horizontal1light3}>
                <div className={styles.divider1Px} />
              </div>
              <div className={styles.horizontal1light4}>
                <div className={styles.divider1Px} />
              </div>
              <img
                className={styles.groupInner}
                alt=""
                src="/group-48098911.svg"
              />
              <img
                className={styles.groupChild1}
                alt=""
                src="/group-48098912.svg"
              />
              <div className={styles.yAxis}>
                <div className={styles.dividerhorizontal1medium}>
                  <div className={styles.divider1px} />
                </div>
              </div>
              <div className={styles.yAxisTitle}>Product Complaint Count</div>
              <div className={styles.k}>5k</div>
              <div className={styles.k1}>4k</div>
              <div className={styles.k2}>3k</div>
              <div className={styles.k3}>2k</div>
              <div className={styles.k4}>1k</div>
              <div className={styles.div26}>0</div>
              <div className={styles.months}>Months</div>
            </div>
          </div>
          <div className={styles.bubbleChart}>
            <div className={styles.complaintDistribution1}>
              <div className={styles.header2}>
                <b className={styles.title2}>
                  Product Complaints for Product Plant Combination Count
                </b>
                <div
                  className={styles.descriptionText2}
                >{`Count of issues of selected parameter Product Complaints for the Product and plant combination. `}</div>
              </div>
              <div className={styles.menubuttonLine}>
                <div className={styles.groupsolidsmall}>
                  <div className={styles.solidsmallleftactivedefaul}>
                    <div className={styles.mastersolidsmallleft}>
                      <div className={styles.filter}>Tab 1</div>
                    </div>
                  </div>
                  <div className={styles.stItem}>
                    <div className={styles.mastersolidsmallmiddle}>
                      <div className={styles.filter}>Tab 2</div>
                    </div>
                  </div>
                  <div className={styles.stItem}>
                    <div className={styles.mastersolidsmallright}>
                      <div className={styles.filter}>Tab 3</div>
                    </div>
                  </div>
                </div>
                <div className={styles.actionRow}>
                  <div className={styles.mediumoutlineprimaryiconLe}>
                    <div className={styles.mastermediumtext}>
                      <div className={styles.content}>
                        <img
                          className={styles.zsIconHomeFill}
                          alt=""
                          src="/icon-container.svg"
                        />
                        <div className={styles.filter}>Filter</div>
                        <img
                          className={styles.iconContainer1}
                          alt=""
                          src="/icon-container.svg"
                        />
                      </div>
                    </div>
                  </div>
                  <div className={styles.smalloutlineprimaryiconOnl}>
                    <div className={styles.mastersmallicon}>
                      <img
                        className={styles.zsIconCaratDown}
                        alt=""
                        src="/zsiconfilter.svg"
                      />
                    </div>
                  </div>
                  <div className={styles.smalloutlineprimaryiconOnl}>
                    <div className={styles.mastersmallicon}>
                      <img
                        className={styles.zsIconCaratDown}
                        alt=""
                        src="/zsiconmore.svg"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className={styles.xGrid}>
                <div className={styles.horizontal1lightParent}>
                  <div className={styles.horizontal1light5}>
                    <div className={styles.divider1Px} />
                  </div>
                  <div className={styles.horizontal1light6}>
                    <div className={styles.divider1Px} />
                  </div>
                  <div className={styles.horizontal1light7}>
                    <div className={styles.divider1Px} />
                  </div>
                  <div className={styles.horizontal1light8}>
                    <div className={styles.divider1Px} />
                  </div>
                  <div className={styles.horizontal1light9}>
                    <div className={styles.divider1Px} />
                  </div>
                </div>
                <div className={styles.horizontal1mediumLight1}>
                  <div className={styles.dividerhorizontal1medium}>
                    <div className={styles.divider1Px1} />
                  </div>
                </div>
              </div>
              <div className={styles.yAxis1}>
                <div className={styles.dividerhorizontal1medium}>
                  <div className={styles.divider1px} />
                </div>
              </div>
              <div className={styles.product7}>Product 7</div>
              <div className={styles.product8}>Product 8</div>
              <div className={styles.horizontal1light10}>
                <div className={styles.divider1Px} />
              </div>
              <div className={styles.horizontal1light11}>
                <div className={styles.divider1Px} />
              </div>
              <div className={styles.product6}>Product 6</div>
              <div className={styles.product5}>Product 5</div>
              <div className={styles.product4}>Product 4</div>
              <div className={styles.product3}>Product 3</div>
              <div className={styles.product2}>Product 2</div>
              <div className={styles.product1}>Product 1</div>
              <div className={styles.horizontal1light12}>
                <div className={styles.divider1Px} />
              </div>
              <div className={styles.horizontal1light13}>
                <div className={styles.divider1Px} />
              </div>
              <div className={styles.horizontal1light14}>
                <div className={styles.divider1Px} />
              </div>
              <div className={styles.horizontal1light15}>
                <div className={styles.divider1Px} />
              </div>
              <div className={styles.horizontal1light16}>
                <div className={styles.divider1Px} />
              </div>
              <div className={styles.horizontal1light17}>
                <div className={styles.divider1Px} />
              </div>
              <div className={styles.footer1}>
                <div className={styles.legend}>
                  <div className={styles.r1}>
                    <div className={styles.legendItem}>
                      <div className={styles.legendItemInner} />
                      <div className={styles.div7}>0-400</div>
                    </div>
                    <div className={styles.legendItem}>
                      <div className={styles.rectangleDiv} />
                      <div className={styles.div7}>400-800</div>
                    </div>
                    <div className={styles.legendItem}>
                      <div className={styles.legendItemChild1} />
                      <div className={styles.div7}>800-1200</div>
                    </div>
                  </div>
                </div>
              </div>
              <div className={styles.clickOnThe}>
                Click on the combination for details
              </div>
            </div>
            <div className={styles.horizontal1mediumLight2}>
              <div className={styles.dividerhorizontal1medium}>
                <div className={styles.divider1Px1} />
              </div>
            </div>
            <div className={styles.series1Parent}>
              <div className={styles.series110}>
                <div className={styles.div30}>Plant 1</div>
              </div>
              <div className={styles.divider1Px21} />
              <div className={styles.div31}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div33}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
              <div className={styles.div35}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
              <div className={styles.div37}>
                <div className={styles.ellipseDiv} />
                <div className={styles.div38}>50</div>
              </div>
              <div className={styles.div39}>
                <div className={styles.ellipseDiv} />
                <div className={styles.div38}>50</div>
              </div>
              <div className={styles.div41}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div43}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div45}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
            </div>
            <div className={styles.series1Group}>
              <div className={styles.series110}>
                <div className={styles.div30}>Plant 2</div>
              </div>
              <div className={styles.divider1Px21} />
              <div className={styles.div31}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div33}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
              <div className={styles.div35}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
              <div className={styles.div37}>
                <div className={styles.ellipseDiv} />
                <div className={styles.div38}>50</div>
              </div>
              <div className={styles.div39}>
                <div className={styles.ellipseDiv} />
                <div className={styles.div38}>50</div>
              </div>
              <div className={styles.div41}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div43}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div45}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
            </div>
            <div className={styles.series1Container}>
              <div className={styles.series110}>
                <div className={styles.div30}>Plant 3</div>
              </div>
              <div className={styles.divider1Px21} />
              <div className={styles.div31}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div33}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
              <div className={styles.div35}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
              <div className={styles.div37}>
                <div className={styles.ellipseDiv} />
                <div className={styles.div38}>50</div>
              </div>
              <div className={styles.div39}>
                <div className={styles.ellipseDiv} />
                <div className={styles.div38}>50</div>
              </div>
              <div className={styles.div41}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div43}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div45}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
            </div>
            <div className={styles.groupDiv}>
              <div className={styles.series110}>
                <div className={styles.div30}>Plant 4</div>
              </div>
              <div className={styles.divider1Px21} />
              <div className={styles.div31}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div33}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
              <div className={styles.div35}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
              <div className={styles.div37}>
                <div className={styles.ellipseDiv} />
                <div className={styles.div38}>50</div>
              </div>
              <div className={styles.div39}>
                <div className={styles.ellipseDiv} />
                <div className={styles.div38}>50</div>
              </div>
              <div className={styles.div41}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div43}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div45}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
            </div>
            <div className={styles.series1Parent1}>
              <div className={styles.series110}>
                <div className={styles.div30}>Plant 5</div>
              </div>
              <div className={styles.divider1Px21} />
              <div className={styles.div31}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div33}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
              <div className={styles.div35}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
              <div className={styles.div37}>
                <div className={styles.ellipseDiv} />
                <div className={styles.div38}>50</div>
              </div>
              <div className={styles.div39}>
                <div className={styles.ellipseDiv} />
                <div className={styles.div38}>50</div>
              </div>
              <div className={styles.div41}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div43}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div45}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
            </div>
            <div className={styles.series1Parent2}>
              <div className={styles.series110}>
                <div className={styles.div30}>Plant 6</div>
              </div>
              <div className={styles.divider1Px21} />
              <div className={styles.div31}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div33}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
              <div className={styles.div35}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
              <div className={styles.div37}>
                <div className={styles.ellipseDiv} />
                <div className={styles.div38}>50</div>
              </div>
              <div className={styles.div39}>
                <div className={styles.ellipseDiv} />
                <div className={styles.div38}>50</div>
              </div>
              <div className={styles.div41}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div43}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div45}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
            </div>
            <div className={styles.series1Parent3}>
              <div className={styles.series110}>
                <div className={styles.div30}>Plant 7</div>
              </div>
              <div className={styles.divider1Px21} />
              <div className={styles.div31}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div33}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
              <div className={styles.div35}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
              <div className={styles.div37}>
                <div className={styles.ellipseDiv} />
                <div className={styles.div38}>50</div>
              </div>
              <div className={styles.div39}>
                <div className={styles.ellipseDiv} />
                <div className={styles.div38}>50</div>
              </div>
              <div className={styles.div41}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div43}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div45}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
            </div>
            <div className={styles.series1Parent4}>
              <div className={styles.series110}>
                <div className={styles.div30}>Plant 8</div>
              </div>
              <div className={styles.divider1Px21} />
              <div className={styles.div31}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div33}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
              <div className={styles.div35}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
              <div className={styles.div37}>
                <div className={styles.ellipseDiv} />
                <div className={styles.div38}>50</div>
              </div>
              <div className={styles.div39}>
                <div className={styles.ellipseDiv} />
                <div className={styles.div38}>50</div>
              </div>
              <div className={styles.div41}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div43}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div45}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
            </div>
            <div className={styles.series1Parent5}>
              <div className={styles.series110}>
                <div className={styles.div30}>Plant 9</div>
              </div>
              <div className={styles.divider1Px21} />
              <div className={styles.div31}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div33}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
              <div className={styles.div35}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
              <div className={styles.div37}>
                <div className={styles.ellipseDiv} />
                <div className={styles.div38}>50</div>
              </div>
              <div className={styles.div39}>
                <div className={styles.ellipseDiv} />
                <div className={styles.div38}>50</div>
              </div>
              <div className={styles.div41}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div43}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div45}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
            </div>
            <div className={styles.series1Parent6}>
              <div className={styles.series119}>
                <div className={styles.div183}>Plant 10</div>
              </div>
              <div className={styles.divider1Px21} />
              <div className={styles.div31}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div33}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
              <div className={styles.div35}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
              <div className={styles.div37}>
                <div className={styles.ellipseDiv} />
                <div className={styles.div38}>50</div>
              </div>
              <div className={styles.div39}>
                <div className={styles.ellipseDiv} />
                <div className={styles.div38}>50</div>
              </div>
              <div className={styles.div41}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div43}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div45}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
            </div>
            <div className={styles.series1Parent7}>
              <div className={styles.series119}>
                <div className={styles.div183}>Plant 11</div>
              </div>
              <div className={styles.divider1Px21} />
              <div className={styles.div31}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div33}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
              <div className={styles.div35}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
              <div className={styles.div37}>
                <div className={styles.ellipseDiv} />
                <div className={styles.div38}>50</div>
              </div>
              <div className={styles.div39}>
                <div className={styles.ellipseDiv} />
                <div className={styles.div38}>50</div>
              </div>
              <div className={styles.div41}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div43}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div45}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
            </div>
            <div className={styles.series1Parent8}>
              <div className={styles.series119}>
                <div className={styles.div183}>Plant 12</div>
              </div>
              <div className={styles.divider1Px21} />
              <div className={styles.div31}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div33}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
              <div className={styles.div35}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
              <div className={styles.div37}>
                <div className={styles.ellipseDiv} />
                <div className={styles.div38}>50</div>
              </div>
              <div className={styles.div39}>
                <div className={styles.ellipseDiv} />
                <div className={styles.div38}>50</div>
              </div>
              <div className={styles.div41}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div43}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div45}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
            </div>
            <div className={styles.series1Parent9}>
              <div className={styles.series119}>
                <div className={styles.div183}>Plant 13</div>
              </div>
              <div className={styles.divider1Px21} />
              <div className={styles.div31}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div33}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
              <div className={styles.div35}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
              <div className={styles.div37}>
                <div className={styles.ellipseDiv} />
                <div className={styles.div38}>50</div>
              </div>
              <div className={styles.div39}>
                <div className={styles.ellipseDiv} />
                <div className={styles.div38}>50</div>
              </div>
              <div className={styles.div41}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div43}>
                <div className={styles.child} />
                <div className={styles.div32}>1100</div>
              </div>
              <div className={styles.div45}>
                <div className={styles.item} />
                <div className={styles.div34}>500</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className={styles.toolbar}>
        <div className={styles.dividerhorizontal1medium}>
          <img className={styles.bgIcon} alt="" src="/vector.svg" />
          <div
            className={styles.supplyChain}
          >{`Supply Chain & Manufacturing Analytics Cloud`}</div>
          <div className={styles.welcomeEdwin}>Welcome Edwin!</div>
          <div className={styles.divider1Px34} />
        </div>
      </div>
    </div>
  );
};

export default QMProductComplaintsCount;
