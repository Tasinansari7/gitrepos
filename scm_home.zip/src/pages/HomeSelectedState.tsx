import { FunctionComponent } from "react";
import "antd/dist/antd.min.css";
import { Radio, Button, AutoComplete } from "antd";
import FormContainer from "../components/FormContainer";
import XSmallsolidprimaryiconRig from "../components/XSmallsolidprimaryiconRig";
import Property1Default from "../components/Property1Default";
import Property1Default1 from "../components/Property1Default1";
import Property1Default2 from "../components/Property1Default2";
import Card from "../components/Card";
import Property1Default4 from "../components/Property1Default4";
import styles from "./HomeSelectedState.module.css";

const HomeSelectedState: FunctionComponent = () => {
  return (
    <div className={styles.homeSelectedState}>
      <div className={styles.textParent}>
        <b className={styles.text}>Source</b>
        <img className={styles.groupChild} alt="" src="/rectangle-3654.svg" />
      </div>
      <FormContainer />
      <Radio className={styles.radioButtons} defaultChecked />
      <div className={styles.selectedAssetView} id="sunb_Menu_container_div">
        <div className={styles.selectedAssetViewChild} />
        <div className={styles.manufacturingDecisionStudio}>
          Manufacturing Decision Studio
        </div>
        <XSmallsolidprimaryiconRig
          xSmallsolidprimaryiconRigBorder="unset"
          xSmallsolidprimaryiconRigDisplay="unset"
          xSmallsolidprimaryiconRigFlexDirection="unset"
          xSmallsolidprimaryiconRigPadding="unset"
          xSmallsolidprimaryiconRigPosition="absolute"
          xSmallsolidprimaryiconRigTop="32px"
          xSmallsolidprimaryiconRigLeft="722px"
        />
        <AutoComplete
          className={styles.inputContainer}
          id="SearchBar_autoComp"
          placeholder="Search App"
          style={{ width: 191 }}
        />
        <div className={styles.accessApplicationsAssociated}>
          Access applications associated with Manufacturing, Engineering and
          Quality domain. Use Manufacturing data and analytics workbench to do
          hands-on analytics on manufacturing data lake
        </div>
        <div className={styles.cards}>
          <div className={styles.card1} id="deviation_analytics_div_card">
            <img
              className={styles.card1Child}
              alt=""
              src="/rectangle-3644.svg"
            />
            <div className={styles.quality}>Quality</div>
            <img className={styles.linechartIcon} alt="" src="/linechart.svg" />
            <b className={styles.deviationAnalytics}>Deviation Analytics</b>
          </div>
          <div className={styles.card4}>
            <img
              className={styles.card1Child}
              alt=""
              src="/rectangle-3644.svg"
            />
            <div className={styles.engineering}>Engineering</div>
            <b className={styles.anomalyDetection}>Anomaly Detection</b>
          </div>
          <div className={styles.card7}>
            <img
              className={styles.card7Child}
              alt=""
              src="/rectangle-3644.svg"
            />
            <img
              className={styles.card7Item}
              alt=""
              src="/rectangle-3644.svg"
            />
            <div className={styles.manufacturing}>Manufacturing</div>
            <div className={styles.manufacturing1}>Manufacturing</div>
            <b className={styles.finiteScheduling}>Finite Scheduling</b>
            <b className={styles.quarticaiWorkbench}>Quartic.ai Workbench</b>
          </div>
          <div className={styles.card2} id="batch_traceability_div">
            <img
              className={styles.card1Child}
              alt=""
              src="/rectangle-3644.svg"
            />
            <div className={styles.quality}>Quality</div>
            <b className={styles.batchTraceability}>Batch Traceability</b>
          </div>
          <div className={styles.card5}>
            <img
              className={styles.card1Child}
              alt=""
              src="/rectangle-3644.svg"
            />
            <div className={styles.engineering}>Engineering</div>
            <b className={styles.safetyIncidentPrediction}>
              Safety Incident Prediction
            </b>
          </div>
          <div className={styles.card71}>
            <img
              className={styles.card1Child}
              alt=""
              src="/rectangle-3644.svg"
            />
            <div className={styles.manufacturing}>Manufacturing</div>
            <b className={styles.manufacturingDataAnd}>
              Manufacturing Data and Analytics Workbench
            </b>
          </div>
          <div className={styles.card3} id="Assesst_health_monitoring">
            <img
              className={styles.card1Child}
              alt=""
              src="/rectangle-3644.svg"
            />
            <div className={styles.manufacturing}>Manufacturing</div>
            <b className={styles.assetHealthMonitoring}>
              Asset Health Monitoring
            </b>
          </div>
          <div className={styles.card6}>
            <img
              className={styles.card1Child}
              alt=""
              src="/rectangle-3644.svg"
            />
            <div className={styles.quality}>Quality</div>
            <b className={styles.abnormalityPrediction}>
              Abnormality Prediction
            </b>
          </div>
          <div className={styles.card8}>
            <img
              className={styles.card1Child}
              alt=""
              src="/rectangle-3644.svg"
            />
            <div className={styles.manufacturing}>Manufacturing</div>
            <b className={styles.deviationAnalytics}>Digital Twin</b>
          </div>
        </div>
      </div>
      <img className={styles.auditIcon} alt="" src="/audit.svg" />
      <img className={styles.apartmentIcon} alt="" src="/apartment.svg" />
      <img className={styles.apiIcon} alt="" src="/api.svg" />
      <img className={styles.alertIcon} alt="" src="/alert.svg" />
      <img className={styles.pullrequestIcon} alt="" src="/pullrequest.svg" />
      <img className={styles.exceptionIcon} alt="" src="/exception.svg" />
      <img
        className={styles.homeSelectedStateChild}
        alt=""
        src="/group-48099208@2x.png"
      />
      <img className={styles.apiIcon1} alt="" src="/api.svg" />
      <img className={styles.controlIcon} alt="" src="/control.svg" />
      <Property1Default
        iconRight="/iconright.svg"
        property1DefaultWidth="94.44%"
        property1DefaultHeight="6.22%"
        property1DefaultPosition="absolute"
        property1DefaultTop="0%"
        property1DefaultRight="0%"
        property1DefaultBottom="93.78%"
        property1DefaultLeft="5.56%"
      />
      <div className={styles.cards1} id="Main_menu_container">
        <Property1Default1
          property1DefaultPosition="absolute"
          property1DefaultTop="0px"
          property1DefaultLeft="0px"
        />
        <Property1Default2
          rectangle3504="/rectangle-3504@2x.png"
          property1DefaultPosition="absolute"
          property1DefaultTop="156px"
          property1DefaultLeft="0px"
        />
        <Card
          imageDimensions="/mask-group@2x.png"
          componentName="/rectangle-3504.svg"
          locationName="Manufacturing Decision Studio"
          operationName="Make"
        />
        <Card
          imageDimensions="/mask-group@2x.png"
          componentName="/rectangle-3504.svg"
          locationName="Distribution and Logistics Hub"
          operationName="Deliver"
          propTop="468px"
          propLeft="8px"
          propWidth="38px"
        />
        <Property1Default4
          property1DefaultPosition="absolute"
          property1DefaultTop="624px"
          property1DefaultLeft="0px"
        />
      </div>
    </div>
  );
};

export default HomeSelectedState;
