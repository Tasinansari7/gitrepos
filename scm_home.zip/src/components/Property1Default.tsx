import { FunctionComponent, useMemo, type CSSProperties } from "react";
import Outlinesmallselected from "./Outlinesmallselected";
import styles from "./Property1Default.module.css";

type Property1DefaultType = {
  iconRight?: string;

  /** Style props */
  property1DefaultWidth?: CSSProperties["width"];
  property1DefaultHeight?: CSSProperties["height"];
  property1DefaultPosition?: CSSProperties["position"];
  property1DefaultTop?: CSSProperties["top"];
  property1DefaultRight?: CSSProperties["right"];
  property1DefaultBottom?: CSSProperties["bottom"];
  property1DefaultLeft?: CSSProperties["left"];
};

const Property1Default: FunctionComponent<Property1DefaultType> = ({
  iconRight,
  property1DefaultWidth,
  property1DefaultHeight,
  property1DefaultPosition,
  property1DefaultTop,
  property1DefaultRight,
  property1DefaultBottom,
  property1DefaultLeft,
}) => {
  const property1DefaultStyle: CSSProperties = useMemo(() => {
    return {
      width: property1DefaultWidth,
      height: property1DefaultHeight,
      position: property1DefaultPosition,
      top: property1DefaultTop,
      right: property1DefaultRight,
      bottom: property1DefaultBottom,
      left: property1DefaultLeft,
    };
  }, [
    property1DefaultWidth,
    property1DefaultHeight,
    property1DefaultPosition,
    property1DefaultTop,
    property1DefaultRight,
    property1DefaultBottom,
    property1DefaultLeft,
  ]);

  return (
    <div className={styles.property1default} style={property1DefaultStyle}>
      <div className={styles.toolbar}>
        <img className={styles.vectorIcon} alt="" src="/vector.svg" />
        <div
          className={styles.supplyChain}
        >{`Supply Chain & Manufacturing Analytics Cloud`}</div>
        <div className={styles.welcomeEdwin}>Welcome Edwin!</div>
        <div className={styles.divider1Px} />
        <Outlinesmallselected
          itemCode="/iconright.svg"
          userRole="Superuser"
          outlinesmallselectedWidth="8.82%"
          outlinesmallselectedPosition="absolute"
          outlinesmallselectedHeight="71.43%"
          outlinesmallselectedTop="14.29%"
          outlinesmallselectedRight="2.21%"
          outlinesmallselectedBottom="14.29%"
          outlinesmallselectedLeft="88.97%"
          outlinesmallselectedFlex="1"
          mastersmallFlex="1"
          masterdropdowntriggerFlex="1"
        />
      </div>
    </div>
  );
};

export default Property1Default;
