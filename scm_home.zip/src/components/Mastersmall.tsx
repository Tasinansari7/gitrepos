import { FunctionComponent, useMemo, type CSSProperties } from "react";
import styles from "./Mastersmall.module.css";

type MastersmallType = {
  iconRight?: string;
  selection?: string;
  zsIconCaratDown?: string;

  /** Style props */
  mastersmallFlex?: CSSProperties["flex"];
  masterdropdowntriggerFlex?: CSSProperties["flex"];
  selectionColor?: CSSProperties["color"];
  selectionFontWeight?: CSSProperties["fontWeight"];
};

const Mastersmall: FunctionComponent<MastersmallType> = ({
  iconRight,
  selection,
  zsIconCaratDown,
  mastersmallFlex,
  masterdropdowntriggerFlex,
  selectionColor,
  selectionFontWeight,
}) => {
  const mastersmallStyle: CSSProperties = useMemo(() => {
    return {
      flex: mastersmallFlex,
    };
  }, [mastersmallFlex]);

  const masterdropdowntriggerStyle: CSSProperties = useMemo(() => {
    return {
      flex: masterdropdowntriggerFlex,
    };
  }, [masterdropdowntriggerFlex]);

  const selectionStyle: CSSProperties = useMemo(() => {
    return {
      color: selectionColor,
      fontWeight: selectionFontWeight,
    };
  }, [selectionColor, selectionFontWeight]);

  return (
    <div className={styles.mastersmall} style={mastersmallStyle}>
      <div
        className={styles.masterdropdowntrigger}
        style={masterdropdowntriggerStyle}
      >
        <img className={styles.iconRight} alt="" src={iconRight} />
        <div className={styles.selection} style={selectionStyle}>
          {selection}
        </div>
        <img className={styles.zsIconCaratDown} alt="" src={zsIconCaratDown} />
      </div>
    </div>
  );
};

export default Mastersmall;
