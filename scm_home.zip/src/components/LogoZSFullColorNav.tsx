import { FunctionComponent, useMemo, type CSSProperties } from "react";
import styles from "./LogoZSFullColorNav.module.css";

type LogoZSFullColorNavType = {
  /** Style props */
  logoZSFullColorNavIconOverflow?: CSSProperties["overflow"];
  logoZSFullColorNavIconPosition?: CSSProperties["position"];
  logoZSFullColorNavIconTop?: CSSProperties["top"];
  logoZSFullColorNavIconLeft?: CSSProperties["left"];
};

const LogoZSFullColorNav: FunctionComponent<LogoZSFullColorNavType> = ({
  logoZSFullColorNavIconOverflow,
  logoZSFullColorNavIconPosition,
  logoZSFullColorNavIconTop,
  logoZSFullColorNavIconLeft,
}) => {
  const logoZSFullColorNavIconStyle: CSSProperties = useMemo(() => {
    return {
      overflow: logoZSFullColorNavIconOverflow,
      position: logoZSFullColorNavIconPosition,
      top: logoZSFullColorNavIconTop,
      left: logoZSFullColorNavIconLeft,
    };
  }, [
    logoZSFullColorNavIconOverflow,
    logoZSFullColorNavIconPosition,
    logoZSFullColorNavIconTop,
    logoZSFullColorNavIconLeft,
  ]);

  return (
    <img
      className={styles.logozsfullColornavIcon}
      alt=""
      src="/logozsfullcolornav.svg"
      style={logoZSFullColorNavIconStyle}
    />
  );
};

export default LogoZSFullColorNav;
