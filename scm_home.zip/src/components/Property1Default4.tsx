import { FunctionComponent, useMemo, type CSSProperties } from "react";
import styles from "./Property1Default4.module.css";

type Property1Default4Type = {
  /** Style props */
  property1DefaultPosition?: CSSProperties["position"];
  property1DefaultTop?: CSSProperties["top"];
  property1DefaultLeft?: CSSProperties["left"];
};

const Property1Default4: FunctionComponent<Property1Default4Type> = ({
  property1DefaultPosition,
  property1DefaultTop,
  property1DefaultLeft,
}) => {
  const property1Default3Style: CSSProperties = useMemo(() => {
    return {
      position: property1DefaultPosition,
      top: property1DefaultTop,
      left: property1DefaultLeft,
    };
  }, [property1DefaultPosition, property1DefaultTop, property1DefaultLeft]);

  return (
    <div className={styles.property1default} style={property1Default3Style}>
      <img className={styles.maskGroupIcon} alt="" src="/mask-group@2x.png" />
      <img
        className={styles.property1defaultChild}
        alt=""
        src="/rectangle-3504.svg"
      />
      <div className={styles.endToEnd}>End-to-End</div>
    </div>
  );
};

export default Property1Default4;
