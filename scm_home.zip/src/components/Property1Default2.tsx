import { FunctionComponent, useMemo, type CSSProperties } from "react";
import styles from "./Property1Default2.module.css";

type Property1Default2Type = {
  rectangle3504?: string;

  /** Style props */
  property1DefaultPosition?: CSSProperties["position"];
  property1DefaultTop?: CSSProperties["top"];
  property1DefaultLeft?: CSSProperties["left"];
};

const Property1Default2: FunctionComponent<Property1Default2Type> = ({
  rectangle3504,
  property1DefaultPosition,
  property1DefaultTop,
  property1DefaultLeft,
}) => {
  const property1Default2Style: CSSProperties = useMemo(() => {
    return {
      position: property1DefaultPosition,
      top: property1DefaultTop,
      left: property1DefaultLeft,
    };
  }, [property1DefaultPosition, property1DefaultTop, property1DefaultLeft]);

  return (
    <div className={styles.property1default} style={property1Default2Style}>
      <img className={styles.maskGroupIcon} alt="" src="/mask-group@2x.png" />
      <img
        className={styles.property1defaultChild}
        alt=""
        src={rectangle3504}
      />
      <div className={styles.integratedSourcingEngineContainer}>
        <span className={styles.integratedSourcingEngineContainer1}>
          <p className={styles.integratedSourcing}>Integrated Sourcing</p>
          <p className={styles.integratedSourcing}>Engine</p>
        </span>
      </div>
      <div className={styles.tag}>
        <div className={styles.text}>Source</div>
        <img className={styles.tagChild} alt="" src="/rectangle-3654.svg" />
      </div>
    </div>
  );
};

export default Property1Default2;
