import { FunctionComponent, useMemo, type CSSProperties } from "react";
import Mastersmall from "./Mastersmall";
import styles from "./Outlinesmalldefault.module.css";

type OutlinesmalldefaultType = {
  iconRight?: string;
  selection?: string;

  /** Style props */
  outlinesmalldefaultFlex?: CSSProperties["flex"];
  mastersmallFlex?: CSSProperties["flex"];
  masterdropdowntriggerFlex?: CSSProperties["flex"];
  selectionColor?: CSSProperties["color"];
  selectionFontWeight?: CSSProperties["fontWeight"];
};

const Outlinesmalldefault: FunctionComponent<OutlinesmalldefaultType> = ({
  iconRight,
  selection,
  outlinesmalldefaultFlex,
  mastersmallFlex,
  masterdropdowntriggerFlex,
  selectionColor,
  selectionFontWeight,
}) => {
  const outlinesmalldefaultStyle: CSSProperties = useMemo(() => {
    return {
      flex: outlinesmalldefaultFlex,
    };
  }, [outlinesmalldefaultFlex]);

  const mastersmallStyle: CSSProperties = useMemo(() => {
    return {
      flex: mastersmallFlex,
    };
  }, [mastersmallFlex]);

  const masterdropdowntriggerStyle: CSSProperties = useMemo(() => {
    return {
      flex: masterdropdowntriggerFlex,
    };
  }, [masterdropdowntriggerFlex]);

  const selectionStyle: CSSProperties = useMemo(() => {
    return {
      color: selectionColor,
      fontWeight: selectionFontWeight,
    };
  }, [selectionColor, selectionFontWeight]);

  return (
    <div
      className={styles.outlinesmalldefault}
      style={outlinesmalldefaultStyle}
    >
      <Mastersmall
        iconRight="/iconright.svg"
        selection="Selection"
        zsIconCaratDown="/zsiconcaratdown.svg"
        mastersmallFlex="unset"
        masterdropdowntriggerFlex="unset"
        selectionColor="#454250"
        selectionFontWeight="unset"
      />
    </div>
  );
};

export default Outlinesmalldefault;
