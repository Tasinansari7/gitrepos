import { FunctionComponent, useMemo, type CSSProperties } from "react";
import styles from "./Card.module.css";

type CardType = {
  imageDimensions?: string;
  componentName?: string;
  locationName?: string;
  operationName?: string;

  /** Style props */
  propTop?: CSSProperties["top"];
  propLeft?: CSSProperties["left"];
  propWidth?: CSSProperties["width"];
};

const Card: FunctionComponent<CardType> = ({
  imageDimensions,
  componentName,
  locationName,
  operationName,
  propTop,
  propLeft,
  propWidth,
}) => {
  const card3Style: CSSProperties = useMemo(() => {
    return {
      top: propTop,
    };
  }, [propTop]);

  const textStyle: CSSProperties = useMemo(() => {
    return {
      left: propLeft,
      width: propWidth,
    };
  }, [propLeft, propWidth]);

  return (
    <div
      className={styles.card3}
      id="Manufacturing_decision_studio_div"
      style={card3Style}
    >
      <img className={styles.maskGroupIcon} alt="" src={imageDimensions} />
      <img className={styles.card3Child} alt="" src={componentName} />
      <div className={styles.manufacturingDecisionStudio}>{locationName}</div>
      <div className={styles.tag}>
        <div className={styles.text} style={textStyle}>
          {operationName}
        </div>
        <img className={styles.tagChild} alt="" src="/rectangle-3654.svg" />
      </div>
    </div>
  );
};

export default Card;
