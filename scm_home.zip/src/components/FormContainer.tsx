import { FunctionComponent } from "react";
import "antd/dist/antd.min.css";
import { Button } from "antd";
import LogoZSFullColorNav from "./LogoZSFullColorNav";
import styles from "./FormContainer.module.css";

const FormContainer: FunctionComponent = () => {
  return (
    <div className={styles.navigationBar}>
      <nav className={styles.sidecontainerbackground} id="main_Navigation">
        <div className={styles.bkdOverlay} />
        <div className={styles.roster}>
          <div className={styles.backgroundFill} />
          <div className={styles.linkItem}>
            <img className={styles.vectorIcon} alt="" src="/vector.svg" />
            <div className={styles.xsmallText}>Logout</div>
          </div>
        </div>
      </nav>
      <Button
        className={styles.home}
        id="homeButton"
        style={{ width: "80px" }}
        type="default"
      />
      <div className={styles.roster1}>
        <div className={styles.backgroundFill1} />
        <div className={styles.linkItem1}>
          <img className={styles.unionIcon} alt="" src="/union.svg" />
          <div className={styles.xsmallText}>
            <p className={styles.quality}>Quality</p>
            <p className={styles.quality}>Monitoring</p>
          </div>
        </div>
      </div>
      <div className={styles.roster2}>
        <div className={styles.backgroundFill1} />
        <div className={styles.linkItem1}>
          <img className={styles.unionIcon} alt="" src="/vector.svg" />
          <div className={styles.xsmallText}>Batch Deep Dive</div>
        </div>
      </div>
      <div className={styles.roster3}>
        <div className={styles.backgroundFill3} />
        <div className={styles.linkItem1}>
          <img className={styles.vectorIcon} alt="" src="/group.svg" />
          <div className={styles.xsmallText}>Product Compaints</div>
        </div>
      </div>
      <div className={styles.roster4}>
        <div className={styles.backgroundFill1} />
        <div className={styles.linkItem}>
          <img className={styles.vectorIcon} alt="" src="/vector.svg" />
          <div className={styles.xsmallText}>Deviations</div>
        </div>
      </div>
      <div className={styles.roster5}>
        <div className={styles.backgroundFill1} />
        <div className={styles.linkItem5}>
          <img className={styles.vectorIcon} alt="" src="/vector.svg" />
          <div className={styles.xsmallText}>CAPA</div>
        </div>
      </div>
      <div className={styles.roster6}>
        <div className={styles.backgroundFill1} />
        <div className={styles.linkItem}>
          <img className={styles.groupIcon1} alt="" src="/group.svg" />
          <div className={styles.xsmallText}>Change Control</div>
        </div>
      </div>
      <LogoZSFullColorNav
        logoZSFullColorNavIconOverflow="unset"
        logoZSFullColorNavIconPosition="absolute"
        logoZSFullColorNavIconTop="8px"
        logoZSFullColorNavIconLeft="8px"
      />
    </div>
  );
};

export default FormContainer;
