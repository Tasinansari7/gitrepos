import { FunctionComponent, useMemo, type CSSProperties } from "react";
import styles from "./Property1Default1.module.css";

type Property1Default1Type = {
  /** Style props */
  property1DefaultPosition?: CSSProperties["position"];
  property1DefaultTop?: CSSProperties["top"];
  property1DefaultLeft?: CSSProperties["left"];
};

const Property1Default1: FunctionComponent<Property1Default1Type> = ({
  property1DefaultPosition,
  property1DefaultTop,
  property1DefaultLeft,
}) => {
  const property1Default1Style: CSSProperties = useMemo(() => {
    return {
      position: property1DefaultPosition,
      top: property1DefaultTop,
      left: property1DefaultLeft,
    };
  }, [property1DefaultPosition, property1DefaultTop, property1DefaultLeft]);

  return (
    <div className={styles.property1default} style={property1Default1Style}>
      <img className={styles.maskGroupIcon} alt="" src="/mask-group@2x.png" />
      <img
        className={styles.property1defaultChild}
        alt=""
        src="/rectangle-3504.svg"
      />
      <div className={styles.integratedPlanningOrchestratContainer}>
        <span className={styles.integratedPlanningOrchestratContainer1}>
          <p className={styles.integratedPlanning}>Integrated Planning</p>
          <p className={styles.integratedPlanning}>Orchestration</p>
        </span>
      </div>
      <div className={styles.tag}>
        <div className={styles.text}>Plan</div>
        <img className={styles.tagChild} alt="" src="/rectangle-3654.svg" />
      </div>
    </div>
  );
};

export default Property1Default1;
