import { FunctionComponent, useMemo, type CSSProperties } from "react";
import Outlinesmalldefault from "./Outlinesmalldefault";
import styles from "./Outlinesmallselected.module.css";

type OutlinesmallselectedType = {
  itemCode?: string;
  userRole?: string;

  /** Style props */
  outlinesmallselectedWidth?: CSSProperties["width"];
  outlinesmallselectedPosition?: CSSProperties["position"];
  outlinesmallselectedHeight?: CSSProperties["height"];
  outlinesmallselectedTop?: CSSProperties["top"];
  outlinesmallselectedRight?: CSSProperties["right"];
  outlinesmallselectedBottom?: CSSProperties["bottom"];
  outlinesmallselectedLeft?: CSSProperties["left"];
  outlinesmallselectedFlex?: CSSProperties["flex"];
  mastersmallFlex?: CSSProperties["flex"];
  masterdropdowntriggerFlex?: CSSProperties["flex"];
};

const Outlinesmallselected: FunctionComponent<OutlinesmallselectedType> = ({
  itemCode,
  userRole,
  outlinesmallselectedWidth,
  outlinesmallselectedPosition,
  outlinesmallselectedHeight,
  outlinesmallselectedTop,
  outlinesmallselectedRight,
  outlinesmallselectedBottom,
  outlinesmallselectedLeft,
  outlinesmallselectedFlex,
  mastersmallFlex,
  masterdropdowntriggerFlex,
}) => {
  const outlinesmallselectedStyle: CSSProperties = useMemo(() => {
    return {
      width: outlinesmallselectedWidth,
      position: outlinesmallselectedPosition,
      height: outlinesmallselectedHeight,
      top: outlinesmallselectedTop,
      right: outlinesmallselectedRight,
      bottom: outlinesmallselectedBottom,
      left: outlinesmallselectedLeft,
    };
  }, [
    outlinesmallselectedWidth,
    outlinesmallselectedPosition,
    outlinesmallselectedHeight,
    outlinesmallselectedTop,
    outlinesmallselectedRight,
    outlinesmallselectedBottom,
    outlinesmallselectedLeft,
  ]);

  const outlinesmalldefaultStyle: CSSProperties = useMemo(() => {
    return {
      flex: outlinesmallselectedFlex,
    };
  }, [outlinesmallselectedFlex]);

  const mastersmallStyle: CSSProperties = useMemo(() => {
    return {
      flex: mastersmallFlex,
    };
  }, [mastersmallFlex]);

  const masterdropdowntriggerStyle: CSSProperties = useMemo(() => {
    return {
      flex: masterdropdowntriggerFlex,
    };
  }, [masterdropdowntriggerFlex]);

  return (
    <div
      className={styles.outlinesmallselected}
      style={outlinesmallselectedStyle}
    >
      <Outlinesmalldefault
        iconRight="/iconright.svg"
        selection="Selection"
        outlinesmalldefaultFlex="unset"
        mastersmallFlex="unset"
        masterdropdowntriggerFlex="unset"
        selectionColor="#1a1628"
        selectionFontWeight="600"
      />
    </div>
  );
};

export default Outlinesmallselected;
