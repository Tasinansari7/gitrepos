import { FunctionComponent, useMemo, type CSSProperties } from "react";
import styles from "./XSmallsolidprimaryiconRig.module.css";

type XSmallsolidprimaryiconRigType = {
  /** Style props */
  xSmallsolidprimaryiconRigBorder?: CSSProperties["border"];
  xSmallsolidprimaryiconRigDisplay?: CSSProperties["display"];
  xSmallsolidprimaryiconRigFlexDirection?: CSSProperties["flexDirection"];
  xSmallsolidprimaryiconRigPadding?: CSSProperties["padding"];
  xSmallsolidprimaryiconRigPosition?: CSSProperties["position"];
  xSmallsolidprimaryiconRigTop?: CSSProperties["top"];
  xSmallsolidprimaryiconRigLeft?: CSSProperties["left"];
};

const XSmallsolidprimaryiconRig: FunctionComponent<
  XSmallsolidprimaryiconRigType
> = ({
  xSmallsolidprimaryiconRigBorder,
  xSmallsolidprimaryiconRigDisplay,
  xSmallsolidprimaryiconRigFlexDirection,
  xSmallsolidprimaryiconRigPadding,
  xSmallsolidprimaryiconRigPosition,
  xSmallsolidprimaryiconRigTop,
  xSmallsolidprimaryiconRigLeft,
}) => {
  const xSmallsolidprimaryiconRigStyle: CSSProperties = useMemo(() => {
    return {
      border: xSmallsolidprimaryiconRigBorder,
      display: xSmallsolidprimaryiconRigDisplay,
      flexDirection: xSmallsolidprimaryiconRigFlexDirection,
      padding: xSmallsolidprimaryiconRigPadding,
      position: xSmallsolidprimaryiconRigPosition,
      top: xSmallsolidprimaryiconRigTop,
      left: xSmallsolidprimaryiconRigLeft,
    };
  }, [
    xSmallsolidprimaryiconRigBorder,
    xSmallsolidprimaryiconRigDisplay,
    xSmallsolidprimaryiconRigFlexDirection,
    xSmallsolidprimaryiconRigPadding,
    xSmallsolidprimaryiconRigPosition,
    xSmallsolidprimaryiconRigTop,
    xSmallsolidprimaryiconRigLeft,
  ]);

  return (
    <div
      className={styles.xSmallsolidprimaryiconRig}
      style={xSmallsolidprimaryiconRigStyle}
    >
      <div className={styles.masterxSmalltext}>
        <div className={styles.content}>
          <img
            className={styles.iconContainer}
            alt=""
            src="/icon-container.svg"
          />
          <div className={styles.button}>Button</div>
          <img
            className={styles.iconContainer1}
            alt=""
            src="/icon-container.svg"
          />
        </div>
      </div>
    </div>
  );
};

export default XSmallsolidprimaryiconRig;
