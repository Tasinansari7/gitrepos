import "antd/dist/antd.min.css";
import { Select, Button } from "antd";
import styles from "./ProductComplaints.module.css";

const ProductComplaints = () => {
  return (
    <div className={styles.productComplaints1}>
      <div className={styles.nestedGrids} />
      <div className={styles.navigationBar}>
        <div className={styles.sidecontainerbackground}>
          <div className={styles.bkdOverlay} />
          <div className={styles.roster}>
            <div className={styles.backgroundFill} />
            <div className={styles.linkItem}>
              <img className={styles.vectorIcon} alt="" src="/vector.svg" />
              <div className={styles.xsmallText}>Logout</div>
            </div>
          </div>
        </div>
        <div className={styles.home}>
          <div className={styles.backgroundFill1} />
          <div className={styles.linkItem1}>
            <img
              className={styles.zsIconHomeFill}
              alt=""
              src="/zsiconhomefill.svg"
            />
            <div className={styles.xsmallText1}>Home</div>
          </div>
        </div>
        <div className={styles.qm}>
          <div className={styles.backgroundFill2} />
          <div className={styles.linkItem2}>
            <img className={styles.unionIcon} alt="" src="/union.svg" />
            <div className={styles.xsmallText}>
              <p className={styles.quality}>Quality</p>
              <p className={styles.quality}>Monitoring</p>
            </div>
          </div>
        </div>
        <div className={styles.dd}>
          <div className={styles.backgroundFill2} />
          <div className={styles.linkItem2}>
            <img className={styles.unionIcon} alt="" src="/group@2x.png" />
            <div className={styles.xsmallText}>Batch Deep Dive</div>
          </div>
        </div>
        <div className={styles.cc}>
          <div className={styles.backgroundFill4} />
          <div className={styles.linkItem2}>
            <img className={styles.vectorIcon} alt="" src="/group.svg" />
            <div className={styles.xsmallText}>Product Compaints</div>
          </div>
        </div>
        <div className={styles.deviations}>
          <div className={styles.backgroundFill2} />
          <div className={styles.linkItem}>
            <img className={styles.vectorIcon} alt="" src="/vector.svg" />
            <div className={styles.xsmallText}>Deviations</div>
          </div>
        </div>
        <div className={styles.capa}>
          <div className={styles.backgroundFill2} />
          <div className={styles.linkItem6}>
            <img className={styles.vectorIcon} alt="" src="/vector.svg" />
            <div className={styles.xsmallText}>CAPA</div>
          </div>
        </div>
        <div className={styles.control}>
          <div className={styles.backgroundFill2} />
          <div className={styles.linkItem}>
            <img className={styles.groupIcon2} alt="" src="/group.svg" />
            <div className={styles.xsmallText}>Change Control</div>
          </div>
        </div>
        <img
          className={styles.logozsfullColornavIcon}
          alt=""
          src="/logozsfullcolornav.svg"
        />
      </div>
      <div className={styles.breadcrumb}>
        <div className={styles.stItem}>
          <div className={styles.stItemLabel}>Home</div>
        </div>
        <div className={styles.componentsseparator}>
          <div className={styles.stItemLabel}>/</div>
        </div>
        <div className={styles.ndItem}>
          <div className={styles.stItemLabel}>All Apps</div>
        </div>
        <div className={styles.componentsseparator1}>
          <div className={styles.stItemLabel}>/</div>
        </div>
        <div className={styles.stItem}>
          <div className={styles.stItemLabel}>Batch Deep Dive</div>
        </div>
        <div className={styles.componentsseparator}>
          <div className={styles.stItemLabel}>/</div>
        </div>
        <div className={styles.lastItem}>
          <div className={styles.stItemLabel}>Product Compaints</div>
        </div>
      </div>
      <div className={styles.headingLeft}>
        <img
          className={styles.zsIconHomeFill}
          alt=""
          src="/zsiconarrowleft.svg"
        />
        <div className={styles.wrapper}>
          <div className={styles.productComplaints}>Product Complaints</div>
          <div className={styles.thisIsA}>This is a subtitle</div>
        </div>
      </div>
      <div className={styles.charts}>
        <div className={styles.complaintDistributionParent}>
          <div className={styles.complaintDistribution}>
            <div className={styles.complaintDistribution1}>
              <div className={styles.header}>
                <b className={styles.title}>Complaint Distribution</b>
                <div className={styles.descriptionText}>
                  Shows distribution of product complaints across months for
                  selected batch
                </div>
              </div>
              <div className={styles.xAxisValuesParent}>
                <div className={styles.xAxisValues}>
                  <div className={styles.series1}>
                    <div className={styles.div}>Jan</div>
                  </div>
                  <div className={styles.series1}>
                    <div className={styles.div}>Feb</div>
                  </div>
                  <div className={styles.series1}>
                    <div className={styles.div}>Mar</div>
                  </div>
                  <div className={styles.series1}>
                    <div className={styles.div}>Apr</div>
                  </div>
                  <div className={styles.series1}>
                    <div className={styles.div}>May</div>
                  </div>
                  <div className={styles.series1}>
                    <div className={styles.div}>Jun</div>
                  </div>
                  <div className={styles.series1}>
                    <div className={styles.div}>Jul</div>
                  </div>
                  <div className={styles.series1}>
                    <div className={styles.div}>Aug</div>
                  </div>
                  <div className={styles.series1}>
                    <div className={styles.div}>Sep</div>
                  </div>
                  <div className={styles.series1}>
                    <div className={styles.div}>Oct</div>
                  </div>
                  <div className={styles.series1}>
                    <div className={styles.div}>Nov</div>
                  </div>
                  <div className={styles.series1}>
                    <div className={styles.div}>Dec</div>
                  </div>
                  <div className={styles.series8}>
                    <div className={styles.div}>Value</div>
                  </div>
                  <div className={styles.series8}>
                    <div className={styles.div}>Value</div>
                  </div>
                  <div className={styles.series8}>
                    <div className={styles.div}>Value</div>
                  </div>
                  <div className={styles.series8}>
                    <div className={styles.div}>Value</div>
                  </div>
                  <div className={styles.series8}>
                    <div className={styles.div}>Value</div>
                  </div>
                </div>
                <div className={styles.horizontal1light}>
                  <div className={styles.divider1Px} />
                </div>
                <div className={styles.horizontal1mediumLight}>
                  <div className={styles.dividerhorizontal1medium}>
                    <div className={styles.divider1Px1} />
                  </div>
                </div>
                <div className={styles.horizontal1light1}>
                  <div className={styles.divider1Px} />
                </div>
                <div className={styles.horizontal1light2}>
                  <div className={styles.divider1Px} />
                </div>
                <div className={styles.horizontal1light3}>
                  <div className={styles.divider1Px} />
                </div>
                <div className={styles.horizontal1light4}>
                  <div className={styles.divider1Px} />
                </div>
                <img
                  className={styles.groupChild}
                  alt=""
                  src="/group-48098911.svg"
                />
                <img
                  className={styles.groupItem}
                  alt=""
                  src="/group-48098912.svg"
                />
                <div className={styles.yAxis}>
                  <div className={styles.dividerhorizontal1medium}>
                    <div className={styles.divider1px} />
                  </div>
                </div>
                <div className={styles.yAxisTitle}>Count of Complaints</div>
                <div className={styles.k}>5k</div>
                <div className={styles.k1}>4k</div>
                <div className={styles.k2}>3k</div>
                <div className={styles.k3}>2k</div>
                <div className={styles.k4}>1k</div>
                <div className={styles.div17}>0</div>
                <div className={styles.months}>Months</div>
              </div>
              <div className={styles.footer}>
                <div className={styles.legend}>
                  <div className={styles.r1}>
                    <div className={styles.legendItem}>
                      <div className={styles.legendItemChild} />
                      <div className={styles.productComplaintCount}>
                        Product Complaint Count
                      </div>
                    </div>
                    <div className={styles.legendItem}>
                      <div className={styles.legendItemItem} />
                      <div className={styles.productComplaintCount}>
                        Product Complaint Count (Past Due)
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className={styles.geographicalDistribution}>
            <div className={styles.header1}>
              <b className={styles.title1}>Geographical Distribution</b>
              <div className={styles.descriptionText1}>
                Shows distribution of product complaints across countries for
                selected batch
              </div>
            </div>
            <div className={styles.menubuttonLine}>
              <div className={styles.groupsolidsmall}>
                <div className={styles.stItem}>
                  <div className={styles.mastersolidsmallleft}>
                    <div className={styles.apply}>Tab 1</div>
                  </div>
                </div>
                <div className={styles.solidsmallmiddleinactivede}>
                  <div className={styles.mastersolidsmallmiddle}>
                    <div className={styles.apply}>Tab 2</div>
                  </div>
                </div>
                <div className={styles.solidsmallrightinactivedef}>
                  <div className={styles.tag}>
                    <div className={styles.geekblue}>geekblue</div>
                    <img className={styles.closeIcon} alt="" src="/close.svg" />
                  </div>
                </div>
              </div>
              <div className={styles.actionRow}>
                <div className={styles.tag1}>
                  <img className={styles.unionIcon1} alt="" src="/union.svg" />
                  <div className={styles.wrap}>
                    <div className={styles.geekblue}>red</div>
                    <img className={styles.closeIcon} alt="" src="/close.svg" />
                  </div>
                </div>
                <div className={styles.tag2}>
                  <img className={styles.unionIcon1} alt="" src="/union.svg" />
                  <div className={styles.wrap}>
                    <div className={styles.geekblue}>orange</div>
                    <img className={styles.closeIcon} alt="" src="/close.svg" />
                  </div>
                </div>
                <div className={styles.tag2}>
                  <img className={styles.unionIcon1} alt="" src="/union.svg" />
                  <div className={styles.wrap}>
                    <div className={styles.geekblue}>orange</div>
                    <img className={styles.closeIcon} alt="" src="/close.svg" />
                  </div>
                </div>
              </div>
            </div>
            <div className={styles.xGrid}>
              <div className={styles.horizontal1lightParent}>
                <div className={styles.horizontal1light5}>
                  <div className={styles.divider1Px} />
                </div>
                <div className={styles.horizontal1light6}>
                  <div className={styles.divider1Px} />
                </div>
                <div className={styles.horizontal1light7}>
                  <div className={styles.divider1Px} />
                </div>
                <div className={styles.horizontal1light8}>
                  <div className={styles.divider1Px} />
                </div>
                <div className={styles.horizontal1light9}>
                  <div className={styles.divider1Px} />
                </div>
              </div>
              <div className={styles.horizontal1mediumLight1}>
                <div className={styles.dividerhorizontal1medium}>
                  <div className={styles.divider1Px1} />
                </div>
              </div>
            </div>
            <div className={styles.footer1}>
              <div className={styles.legend}>
                <div className={styles.r1}>
                  <div className={styles.legendItem}>
                    <div className={styles.legendItemInner} />
                    <div className={styles.productComplaintCount}>Delayed</div>
                  </div>
                  <div className={styles.legendItem}>
                    <div className={styles.rectangleDiv} />
                    <div className={styles.productComplaintCount}>Open</div>
                  </div>
                  <div className={styles.legendItem}>
                    <div className={styles.legendItemChild1} />
                    <div className={styles.productComplaintCount}>Closed</div>
                  </div>
                </div>
              </div>
            </div>
            <div className={styles.xAxisValuesGroup}>
              <div className={styles.xAxisValues1}>
                <div className={styles.series110}>
                  <div className={styles.div}>0</div>
                </div>
                <div className={styles.series1}>
                  <div className={styles.div}>250</div>
                </div>
                <div className={styles.series1}>
                  <div className={styles.div}>500</div>
                </div>
                <div className={styles.series1}>
                  <div className={styles.div}>750</div>
                </div>
                <div className={styles.series1}>
                  <div className={styles.div}>1000</div>
                </div>
                <div className={styles.series1}>
                  <div className={styles.div}>1250</div>
                </div>
                <div className={styles.series1}>
                  <div className={styles.div}>1500</div>
                </div>
                <div className={styles.series1}>
                  <div className={styles.div}>1750</div>
                </div>
                <div className={styles.series1}>
                  <div className={styles.div}>2000</div>
                </div>
                <div className={styles.series8}>
                  <div className={styles.div}>Value</div>
                </div>
                <div className={styles.series8}>
                  <div className={styles.div}>Value</div>
                </div>
                <div className={styles.series8}>
                  <div className={styles.div}>Value</div>
                </div>
                <div className={styles.series8}>
                  <div className={styles.div}>Value</div>
                </div>
                <div className={styles.series8}>
                  <div className={styles.div}>Value</div>
                </div>
              </div>
              <div className={styles.componentsheadingLeft}>
                <img
                  className={styles.arrowleftIcon}
                  alt=""
                  src="/arrowleft.svg"
                />
                <div className={styles.wrapper}>
                  <div className={styles.avatar}>
                    <img
                      className={styles.aspectRatioKeeperAddition}
                      alt=""
                      src="/aspect-ratio-keeper--additionally-45-rotated-auto-layout@2x.png"
                    />
                  </div>
                  <div className={styles.title2}>Title</div>
                </div>
              </div>
              <div className={styles.yAxisTitle1}>Countries</div>
              <div className={styles.australia1000500Container}>
                <span className={styles.australia1000500Container1}>
                  <p className={styles.australia}>Australia</p>
                  <p className={styles.quality}>1000, 500, 250</p>
                </span>
              </div>
              <div className={styles.italy1000500Container}>
                <span className={styles.australia1000500Container1}>
                  <p className={styles.australia}>Italy</p>
                  <p className={styles.quality}>1000, 500, 250</p>
                </span>
              </div>
              <div className={styles.netherlands1000500Container}>
                <span className={styles.australia1000500Container1}>
                  <p className={styles.australia}>Netherlands</p>
                  <p className={styles.quality}>1000, 500, 250</p>
                </span>
              </div>
              <div className={styles.brazil1000500Container}>
                <span className={styles.australia1000500Container1}>
                  <p className={styles.australia}>Brazil</p>
                  <p className={styles.quality}>1000, 500, 250</p>
                </span>
              </div>
              <div className={styles.germany1000500Container}>
                <span className={styles.australia1000500Container1}>
                  <p className={styles.australia}>Germany</p>
                  <p className={styles.quality}>1000, 500, 250</p>
                </span>
              </div>
              <div className={styles.uk1000500Container}>
                <span className={styles.australia1000500Container1}>
                  <p className={styles.australia}>UK</p>
                  <p className={styles.quality}>1000, 500, 250</p>
                </span>
              </div>
              <div className={styles.usa1000500Container}>
                <span className={styles.australia1000500Container1}>
                  <p className={styles.australia}>USA</p>
                  <p className={styles.quality}>1000, 500, 250</p>
                </span>
              </div>
              <div className={styles.countOfComplaints}>
                Count of Complaints
              </div>
              <div className={styles.trackDuration}>
                <div className={styles.mastertracktiny8} />
              </div>
              <div className={styles.horizontal1mediumLightParent}>
                <div className={styles.horizontal1mediumLight2}>
                  <div className={styles.dividerhorizontal1medium}>
                    <div className={styles.divider1Px1} />
                  </div>
                </div>
                <div className={styles.trackDuration1}>
                  <div className={styles.mastertracktiny8} />
                </div>
                <div className={styles.trackDuration2}>
                  <div className={styles.mastertracktiny8} />
                </div>
                <div className={styles.trackDuration3}>
                  <div className={styles.mastertracktiny8} />
                </div>
                <div className={styles.trackDuration4}>
                  <div className={styles.mastertracktiny8} />
                </div>
                <div className={styles.trackDuration5}>
                  <div className={styles.mastertracktiny8} />
                </div>
                <div className={styles.trackDuration6}>
                  <div className={styles.mastertracktiny8} />
                </div>
                <div className={styles.trackEllapsedGroup}>
                  <div className={styles.trackEllapsedGroup}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar20}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar30}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar40}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar50}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar60}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar70}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar80}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar90}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar100}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                </div>
                <div className={styles.trackEllapsedGroup1}>
                  <div className={styles.tracksnackBar101}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar201}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar301}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar401}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar501}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar601}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar701}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar801}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar901}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar1001}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                </div>
                <div className={styles.trackEllapsedGroup2}>
                  <div className={styles.tracksnackBar102}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar202}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar302}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar402}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar502}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar602}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar702}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar802}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar902}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar1002}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                </div>
                <div className={styles.trackEllapsedGroup3}>
                  <div className={styles.tracksnackBar103}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar203}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar303}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar403}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar503}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar603}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar703}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar803}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar903}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar1003}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                </div>
                <div className={styles.trackEllapsedGroup4}>
                  <div className={styles.tracksnackBar104}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar204}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar304}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar404}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar504}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar604}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar704}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar804}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar904}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar1004}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                </div>
                <div className={styles.trackEllapsedGroup5}>
                  <div className={styles.tracksnackBar105}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar205}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar305}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar405}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar505}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar605}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar705}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar805}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar905}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar1005}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                </div>
                <div className={styles.trackEllapsedGroup6}>
                  <div className={styles.tracksnackBar106}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar206}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar306}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar406}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar506}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar606}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar706}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar806}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar906}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar1006}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                </div>
                <div className={styles.trackEllapsedGroup7}>
                  <div className={styles.tracksnackBar107}>
                    <div className={styles.mastertracktiny877} />
                  </div>
                  <div className={styles.tracksnackBar20}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar30}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar40}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar50}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar60}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar70}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar80}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar90}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar100}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                </div>
                <div className={styles.trackEllapsedGroup8}>
                  <div className={styles.tracksnackBar108}>
                    <div className={styles.mastertracktiny877} />
                  </div>
                  <div className={styles.tracksnackBar201}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar301}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar401}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar501}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar601}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar701}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar801}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar901}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar1001}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                </div>
                <div className={styles.trackEllapsedGroup9}>
                  <div className={styles.tracksnackBar109}>
                    <div className={styles.mastertracktiny877} />
                  </div>
                  <div className={styles.tracksnackBar203}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar303}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar403}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar503}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar603}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar703}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar803}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar903}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar1003}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                </div>
                <div className={styles.trackEllapsedGroup10}>
                  <div className={styles.tracksnackBar1010}>
                    <div className={styles.mastertracktiny877} />
                  </div>
                  <div className={styles.tracksnackBar204}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar304}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar404}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar504}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar604}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar704}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar804}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar904}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar1004}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                </div>
                <div className={styles.trackEllapsedGroup11}>
                  <div className={styles.tracksnackBar1011}>
                    <div className={styles.mastertracktiny877} />
                  </div>
                  <div className={styles.tracksnackBar202}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar302}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar402}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar502}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar602}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar702}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar802}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar902}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar1002}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                </div>
                <div className={styles.trackEllapsedGroup12}>
                  <div className={styles.tracksnackBar1012}>
                    <div className={styles.mastertracktiny877} />
                  </div>
                  <div className={styles.tracksnackBar205}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar305}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar405}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar505}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar605}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar705}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar805}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar905}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar1005}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                </div>
                <div className={styles.trackEllapsedGroup13}>
                  <div className={styles.tracksnackBar1013}>
                    <div className={styles.mastertracktiny877} />
                  </div>
                  <div className={styles.tracksnackBar206}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar306}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar406}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar506}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar606}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar706}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar806}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar906}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                  <div className={styles.tracksnackBar1006}>
                    <div className={styles.mastertracktiny87} />
                  </div>
                </div>
              </div>
            </div>
            <div className={styles.mouseHoverThe}>
              Mouse hover the bar to see more details
            </div>
            <div className={styles.hover}>
              <div className={styles.dividerhorizontal1medium}>
                <div className={styles.scrollBkgd} />
                <div className={styles.scrollHead} />
              </div>
            </div>
          </div>
          <div className={styles.closedComplaintCount}>
            <div className={styles.header2}>
              <b className={styles.title1}>Closed Complaint Count</b>
              <div className={styles.descriptionText2}>
                Shows the count of product complaints for the selected batch
                closed in current month and the distribution of these cases
                across months based on opening date.
              </div>
            </div>
            <div className={styles.series1Parent}>
              <div className={styles.series112}>
                <div className={styles.div32}>Cases opened in</div>
              </div>
              <div className={styles.xAxisValues2}>
                <div className={styles.series113}>
                  <div className={styles.div33}>Jan</div>
                </div>
                <div className={styles.series113}>
                  <div className={styles.div33}>Feb</div>
                </div>
                <div className={styles.series113}>
                  <div className={styles.div33}>Mar</div>
                </div>
                <div className={styles.series113}>
                  <div className={styles.div33}>Apr</div>
                </div>
                <div className={styles.series113}>
                  <div className={styles.div37}>May</div>
                </div>
                <div className={styles.series113}>
                  <div className={styles.div33}>Jun</div>
                </div>
                <div className={styles.series113}>
                  <div className={styles.div33}>Jul</div>
                </div>
                <div className={styles.series113}>
                  <div className={styles.div33}>Aug</div>
                </div>
                <div className={styles.series113}>
                  <div className={styles.div33}>Sep</div>
                </div>
                <div className={styles.series113}>
                  <div className={styles.div33}>Oct</div>
                </div>
                <div className={styles.series113}>
                  <div className={styles.div33}>Nov</div>
                </div>
                <div className={styles.series191}>
                  <div className={styles.div}>Dec</div>
                </div>
                <div className={styles.series82}>
                  <div className={styles.div}>Value</div>
                </div>
                <div className={styles.series82}>
                  <div className={styles.div}>Value</div>
                </div>
                <div className={styles.series82}>
                  <div className={styles.div}>Value</div>
                </div>
                <div className={styles.series82}>
                  <div className={styles.div}>Value</div>
                </div>
                <div className={styles.series82}>
                  <div className={styles.div}>Value</div>
                </div>
              </div>
              <div className={styles.xAxisValues3}>
                <div className={styles.series115}>
                  <div className={styles.div33}>21</div>
                </div>
                <div className={styles.series113}>
                  <div className={styles.div33}>25</div>
                </div>
                <div className={styles.series113}>
                  <div className={styles.div33}>32</div>
                </div>
                <div className={styles.series113}>
                  <div className={styles.div33}>15</div>
                </div>
                <div className={styles.series113}>
                  <div className={styles.div37}>19</div>
                </div>
                <div className={styles.series113}>
                  <div className={styles.div33}>08</div>
                </div>
                <div className={styles.series113}>
                  <div className={styles.div33}>20</div>
                </div>
                <div className={styles.series113}>
                  <div className={styles.div33}>32</div>
                </div>
                <div className={styles.series113}>
                  <div className={styles.div33}>28</div>
                </div>
                <div className={styles.series113}>
                  <div className={styles.div33}>17</div>
                </div>
                <div className={styles.series192}>
                  <div className={styles.div}>Dec</div>
                </div>
                <div className={styles.series83}>
                  <div className={styles.div}>Value</div>
                </div>
                <div className={styles.series83}>
                  <div className={styles.div}>Value</div>
                </div>
                <div className={styles.series83}>
                  <div className={styles.div}>Value</div>
                </div>
                <div className={styles.series83}>
                  <div className={styles.div}>Value</div>
                </div>
                <div className={styles.series83}>
                  <div className={styles.div}>Value</div>
                </div>
                <div className={styles.series113}>
                  <div className={styles.div33}>13</div>
                </div>
              </div>
            </div>
            <div className={styles.menubuttonLine}>
              <div className={styles.groupsolidsmall}>
                <div className={styles.stItem}>
                  <div className={styles.mastersolidsmallleft}>
                    <div className={styles.apply}>Tab 1</div>
                  </div>
                </div>
                <div className={styles.solidsmallmiddleinactivede}>
                  <div className={styles.mastersolidsmallmiddle}>
                    <div className={styles.apply}>Tab 2</div>
                  </div>
                </div>
                <div className={styles.solidsmallrightinactivedef}>
                  <div className={styles.tag}>
                    <div className={styles.geekblue}>geekblue</div>
                    <img className={styles.closeIcon} alt="" src="/close.svg" />
                  </div>
                </div>
              </div>
              <div className={styles.actionRow}>
                <div className={styles.tag1}>
                  <img className={styles.unionIcon1} alt="" src="/union.svg" />
                  <div className={styles.wrap}>
                    <div className={styles.geekblue}>red</div>
                    <img className={styles.closeIcon} alt="" src="/close.svg" />
                  </div>
                </div>
                <div className={styles.tag2}>
                  <img className={styles.unionIcon1} alt="" src="/union.svg" />
                  <div className={styles.wrap}>
                    <div className={styles.geekblue}>orange</div>
                    <img className={styles.closeIcon} alt="" src="/close.svg" />
                  </div>
                </div>
                <div className={styles.tag2}>
                  <img className={styles.unionIcon1} alt="" src="/union.svg" />
                  <div className={styles.wrap}>
                    <div className={styles.geekblue}>orange</div>
                    <img className={styles.closeIcon} alt="" src="/close.svg" />
                  </div>
                </div>
              </div>
            </div>
            <b className={styles.closedCasesIn}>Closed cases in Dec: 250</b>
          </div>
          <div className={styles.caseStatus}>
            <div className={styles.basicXyAxis}>
              <div className={styles.header3}>
                <b className={styles.title4}>Case Status</b>
                <div className={styles.descriptionText3}>
                  Shows product complaint count for last 6 months based on
                  toggle selection
                </div>
              </div>
              <div className={styles.menubuttonLine2}>
                <div className={styles.groupsolidsmall}>
                  <div className={styles.stItem}>
                    <div className={styles.mastersolidsmallleft}>
                      <div className={styles.apply}>Tab 1</div>
                    </div>
                  </div>
                  <div className={styles.solidsmallmiddleinactivede}>
                    <div className={styles.mastersolidsmallmiddle}>
                      <div className={styles.apply}>Tab 2</div>
                    </div>
                  </div>
                  <div className={styles.solidsmallrightinactivedef}>
                    <div className={styles.tag}>
                      <div className={styles.geekblue}>geekblue</div>
                      <img
                        className={styles.closeIcon}
                        alt=""
                        src="/close.svg"
                      />
                    </div>
                  </div>
                </div>
                <div className={styles.actionRow}>
                  <div className={styles.tag1}>
                    <img
                      className={styles.unionIcon1}
                      alt=""
                      src="/union.svg"
                    />
                    <div className={styles.wrap}>
                      <div className={styles.geekblue}>red</div>
                      <img
                        className={styles.closeIcon}
                        alt=""
                        src="/close.svg"
                      />
                    </div>
                  </div>
                  <div className={styles.tag2}>
                    <img
                      className={styles.unionIcon1}
                      alt=""
                      src="/union.svg"
                    />
                    <div className={styles.wrap}>
                      <div className={styles.geekblue}>orange</div>
                      <img
                        className={styles.closeIcon}
                        alt=""
                        src="/close.svg"
                      />
                    </div>
                  </div>
                  <div className={styles.tag2}>
                    <img
                      className={styles.unionIcon1}
                      alt=""
                      src="/union.svg"
                    />
                    <div className={styles.wrap}>
                      <div className={styles.geekblue}>orange</div>
                      <img
                        className={styles.closeIcon}
                        alt=""
                        src="/close.svg"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className={styles.groupsolidsmall3}>
                <div className={styles.stItem}>
                  <div className={styles.mastersolidsmallleft}>
                    <div className={styles.apply}>Closed</div>
                  </div>
                </div>
                <div className={styles.solidsmallmiddleinactivede3}>
                  <div className={styles.mastersolidsmallmiddle}>
                    <div className={styles.apply}>Tab 2</div>
                  </div>
                </div>
                <div className={styles.solidsmallrightinactivedef}>
                  <div className={styles.tag}>
                    <div className={styles.geekblue}>geekblue</div>
                    <img className={styles.closeIcon} alt="" src="/close.svg" />
                  </div>
                </div>
              </div>
              <div className={styles.horizontal1light10}>
                <div className={styles.divider1Px} />
              </div>
              <div className={styles.horizontal1light11}>
                <div className={styles.divider1Px} />
              </div>
              <div className={styles.footer2}>
                <div className={styles.legend}>
                  <div className={styles.r1}>
                    <div className={styles.legendItem}>
                      <div className={styles.legendItemChild2} />
                      <div className={styles.productComplaintCount}>Closed</div>
                    </div>
                    <div className={styles.legendItem}>
                      <div className={styles.legendItemChild3} />
                      <div className={styles.productComplaintCount}>
                        Closed (Delayed)
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className={styles.xAxisValues4}>
              <div className={styles.series113}>
                <div className={styles.div33}>Jan</div>
              </div>
              <div className={styles.series1}>
                <div className={styles.div68}>Feb</div>
              </div>
              <div className={styles.series1}>
                <div className={styles.div68}>Mar</div>
              </div>
              <div className={styles.series1}>
                <div className={styles.div68}>Apr</div>
              </div>
              <div className={styles.series1}>
                <div className={styles.div68}>May</div>
              </div>
              <div className={styles.series1}>
                <div className={styles.div72}>Jun</div>
              </div>
              <div className={styles.series83}>
                <div className={styles.div}>Value</div>
              </div>
              <div className={styles.series83}>
                <div className={styles.div}>Value</div>
              </div>
              <div className={styles.series83}>
                <div className={styles.div}>Value</div>
              </div>
              <div className={styles.series83}>
                <div className={styles.div}>Value</div>
              </div>
              <div className={styles.series83}>
                <div className={styles.div}>Value</div>
              </div>
            </div>
            <div className={styles.horizontal1light12}>
              <div className={styles.divider1Px} />
            </div>
            <div className={styles.horizontal1light13}>
              <div className={styles.divider1Px} />
            </div>
            <div className={styles.horizontal1light14}>
              <div className={styles.divider1Px} />
            </div>
            <div className={styles.horizontal1mediumLight3}>
              <div className={styles.dividerhorizontal1medium}>
                <div className={styles.divider1Px1} />
              </div>
            </div>
            <div className={styles.componentsheadingLeft1}>
              <img
                className={styles.arrowleftIcon}
                alt=""
                src="/arrowleft.svg"
              />
              <div className={styles.wrapper}>
                <div className={styles.avatar}>
                  <img
                    className={styles.aspectRatioKeeperAddition}
                    alt=""
                    src="/aspect-ratio-keeper--additionally-45-rotated-auto-layout@2x.png"
                  />
                </div>
                <div className={styles.title2}>Title</div>
              </div>
            </div>
            <div className={styles.yAxisTitle2}>Count of Complaints</div>
            <div className={styles.zsIconArrowRightParent}>
              <img
                className={styles.zsIconArrowRight}
                alt=""
                src="/zsiconarrowright.svg"
              />
              <div className={styles.yAxisTitle3}>View last 6 months</div>
            </div>
            <div className={styles.div78}>500</div>
            <div className={styles.div79}>400</div>
            <div className={styles.div80}>300</div>
            <div className={styles.div81}>200</div>
            <div className={styles.div82}>100</div>
            <div className={styles.div83}>0</div>
            <div className={styles.days}>Days</div>
            <div className={styles.bgDark} />
            <div className={styles.bgDark1} />
            <div className={styles.bgDark2} />
            <div className={styles.bgDark3} />
            <div className={styles.bgDark4} />
            <div className={styles.bgDark5} />
            <div className={styles.bgDark6} />
            <div className={styles.bgDark7} />
            <div className={styles.bgDark8} />
            <div className={styles.bgDark9} />
            <div className={styles.bgDark10} />
            <div className={styles.bgDark11} />
            <div className={styles.clickOnA}>
              Click on a bar to get more details about distribution of the
              complaint types for selected month.
            </div>
          </div>
          <div className={styles.resolutionDistribution}>
            <div className={styles.basicXyAxis1}>
              <div className={styles.header4}>
                <b className={styles.title6}>Resolution Distribution</b>
                <div className={styles.descriptionText4}>
                  Graph shows the product complaint count against days bucket
                  for selected batch based on open /closed status toggle
                </div>
              </div>
              <div className={styles.menubuttonLine3}>
                <div className={styles.groupsolidsmall}>
                  <div className={styles.stItem}>
                    <div className={styles.mastersolidsmallleft}>
                      <div className={styles.apply}>Tab 1</div>
                    </div>
                  </div>
                  <div className={styles.solidsmallmiddleinactivede}>
                    <div className={styles.mastersolidsmallmiddle}>
                      <div className={styles.apply}>Tab 2</div>
                    </div>
                  </div>
                  <div className={styles.solidsmallrightinactivedef}>
                    <div className={styles.tag}>
                      <div className={styles.geekblue}>geekblue</div>
                      <img
                        className={styles.closeIcon}
                        alt=""
                        src="/close.svg"
                      />
                    </div>
                  </div>
                </div>
                <div className={styles.actionRow}>
                  <div className={styles.tag1}>
                    <img
                      className={styles.unionIcon1}
                      alt=""
                      src="/union.svg"
                    />
                    <div className={styles.wrap}>
                      <div className={styles.geekblue}>red</div>
                      <img
                        className={styles.closeIcon}
                        alt=""
                        src="/close.svg"
                      />
                    </div>
                  </div>
                  <div className={styles.tag2}>
                    <img
                      className={styles.unionIcon1}
                      alt=""
                      src="/union.svg"
                    />
                    <div className={styles.wrap}>
                      <div className={styles.geekblue}>orange</div>
                      <img
                        className={styles.closeIcon}
                        alt=""
                        src="/close.svg"
                      />
                    </div>
                  </div>
                  <div className={styles.tag2}>
                    <img
                      className={styles.unionIcon1}
                      alt=""
                      src="/union.svg"
                    />
                    <div className={styles.wrap}>
                      <div className={styles.geekblue}>orange</div>
                      <img
                        className={styles.closeIcon}
                        alt=""
                        src="/close.svg"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className={styles.groupsolidsmall5}>
                <div className={styles.stItem}>
                  <div className={styles.mastersolidsmallleft}>
                    <div className={styles.apply}>Closed</div>
                  </div>
                </div>
                <div className={styles.solidsmallmiddleinactivede3}>
                  <div className={styles.mastersolidsmallmiddle}>
                    <div className={styles.apply}>Tab 2</div>
                  </div>
                </div>
                <div className={styles.solidsmallrightinactivedef}>
                  <div className={styles.tag}>
                    <div className={styles.geekblue}>geekblue</div>
                    <img className={styles.closeIcon} alt="" src="/close.svg" />
                  </div>
                </div>
              </div>
              <div className={styles.yAxisTitle4}>Count of Complaints</div>
            </div>
            <div className={styles.horizontal1lightGroup}>
              <div className={styles.horizontal1light15}>
                <div className={styles.divider1Px} />
              </div>
              <div className={styles.horizontal1light16}>
                <div className={styles.divider1Px} />
              </div>
              <div className={styles.xAxisValues5}>
                <div className={styles.series113}>
                  <div className={styles.div33}>0-15</div>
                </div>
                <div className={styles.series1}>
                  <div className={styles.div68}>16-29</div>
                </div>
                <div className={styles.series1}>
                  <div className={styles.div68}>30-44</div>
                </div>
                <div className={styles.series1}>
                  <div className={styles.div68}>45-60</div>
                </div>
                <div className={styles.series1}>
                  <div className={styles.div88}>60+</div>
                </div>
                <div className={styles.series83}>
                  <div className={styles.div}>Value</div>
                </div>
                <div className={styles.series83}>
                  <div className={styles.div}>Value</div>
                </div>
                <div className={styles.series83}>
                  <div className={styles.div}>Value</div>
                </div>
                <div className={styles.series83}>
                  <div className={styles.div}>Value</div>
                </div>
                <div className={styles.series83}>
                  <div className={styles.div}>Value</div>
                </div>
              </div>
              <div className={styles.horizontal1light17}>
                <div className={styles.divider1Px} />
              </div>
              <div className={styles.horizontal1light18}>
                <div className={styles.divider1Px} />
              </div>
              <div className={styles.horizontal1light19}>
                <div className={styles.divider1Px} />
              </div>
              <div className={styles.horizontal1mediumLight4}>
                <div className={styles.dividerhorizontal1medium}>
                  <div className={styles.divider1Px1} />
                </div>
              </div>
              <div className={styles.componentsheadingLeft2}>
                <img
                  className={styles.arrowleftIcon}
                  alt=""
                  src="/arrowleft.svg"
                />
                <div className={styles.wrapper}>
                  <div className={styles.avatar}>
                    <img
                      className={styles.aspectRatioKeeperAddition}
                      alt=""
                      src="/aspect-ratio-keeper--additionally-45-rotated-auto-layout@2x.png"
                    />
                  </div>
                  <div className={styles.title2}>Title</div>
                </div>
              </div>
              <div className={styles.k5}>5k</div>
              <div className={styles.k6}>4k</div>
              <div className={styles.k7}>3k</div>
              <div className={styles.k8}>2k</div>
              <div className={styles.k9}>1k</div>
              <div className={styles.div94}>0</div>
              <div className={styles.days1}>Days</div>
              <div className={styles.bgDark12} />
              <div className={styles.bgDark13} />
              <div className={styles.bgDark14} />
              <div className={styles.bgDark15} />
              <div className={styles.bgDark16} />
            </div>
            <div className={styles.clickOnThe}>
              Click on the bar to view more details
            </div>
          </div>
        </div>
      </div>
      <div className={styles.series133}>
        <div className={styles.div33}>Jun</div>
      </div>
      <div className={styles.toolbar}>
        <div className={styles.dividerhorizontal1medium}>
          <img className={styles.bgIcon} alt="" src="/vector.svg" />
          <div
            className={styles.supplyChain}
          >{`Supply Chain & Manufacturing Analytics Cloud`}</div>
          <div className={styles.welcomeEdwin}>Welcome Edwin!</div>
          <div className={styles.divider1Px25} />
        </div>
      </div>
      <div className={styles.summaryWrapper}>
        <div className={styles.summary}>
          <div className={styles.filterMenu} />
          <div className={styles.bgParent}>
            <img className={styles.bgIcon} alt="" src="/bg.svg" />
            <div className={styles.summary1}>
              <div className={styles.previousMonthCases}>
                Previous Month Cases
              </div>
              <div className={styles.openCases}>Open Cases</div>
              <div className={styles.resolutionTimeDays}>
                Resolution Time (Days)
              </div>
              <div className={styles.div96}>87</div>
              <div className={styles.div97}>4%</div>
              <div className={styles.opened}>Opened</div>
              <div className={styles.current}>Current</div>
              <div className={styles.parent}>
                <div className={styles.div98}>9</div>
                <div className={styles.min}>Min</div>
              </div>
              <div className={styles.closed2}>Closed</div>
              <div className={styles.pastDueDate}>Past Due Date</div>
              <div className={styles.div99}>225</div>
              <div className={styles.avgParent}>
                <div className={styles.avg}>Avg</div>
                <div className={styles.div100}>11</div>
              </div>
              <div className={styles.div101}>7%</div>
              <div className={styles.maxParent}>
                <div className={styles.avg}>Max</div>
                <div className={styles.div100}>15</div>
              </div>
              <div className={styles.text}>
                <div className={styles.textbodyNormal}>
                  <div className={styles.div}>Summary</div>
                </div>
              </div>
            </div>
            <Select
              className={styles.calendar}
              placeholder="Year"
              style={{ width: "272px" }}
              virtual={false}
              showArrow={false}
            >{` `}</Select>
            <div className={styles.calendar1}>
              <div className={styles.text1}>
                <div className={styles.textbodyNormal}>
                  <div className={styles.div}>Product</div>
                </div>
              </div>
              <div className={styles.outlinesmallselected}>
                <div className={styles.outlinesmallselected1}>
                  <div className={styles.mastersmall}>
                    <div className={styles.masterdropdowntrigger}>
                      <img
                        className={styles.iconRight}
                        alt=""
                        src="/iconright.svg"
                      />
                      <div className={styles.div}>Product_7</div>
                      <img
                        className={styles.zsIconCaratDown}
                        alt=""
                        src="/zsiconcaratdown.svg"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className={styles.calendar2}>
              <div className={styles.text2}>
                <div className={styles.textbodyNormal}>
                  <div className={styles.div}>Plant</div>
                </div>
              </div>
              <div className={styles.outlinesmallselected}>
                <div className={styles.outlinesmallselected1}>
                  <div className={styles.mastersmall}>
                    <div className={styles.masterdropdowntrigger}>
                      <img
                        className={styles.iconRight}
                        alt=""
                        src="/iconright.svg"
                      />
                      <div className={styles.div}>Plant_4</div>
                      <img
                        className={styles.zsIconCaratDown}
                        alt=""
                        src="/zsiconcaratdown.svg"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className={styles.calendar3}>
              <div className={styles.text3}>
                <div className={styles.textbodyNormal}>
                  <div className={styles.div}>Batch</div>
                </div>
              </div>
              <div className={styles.mastersmall2}>
                <div className={styles.masterdropdowntrigger2}>
                  <div className={styles.div103}>1750201207</div>
                  <img
                    className={styles.iconRight2}
                    alt=""
                    src="/iconright.svg"
                  />
                  <img
                    className={styles.zsIconCaratDown2}
                    alt=""
                    src="/zsiconcaratdown.svg"
                  />
                </div>
              </div>
              <img
                className={styles.zsIconSearch}
                alt=""
                src="/zsiconsearch.svg"
              />
            </div>
            <div className={styles.frameWrapper}>
              <div className={styles.mediumoutlineprimarytextOnParent}>
                <Button type="default">Reset</Button>
                <div className={styles.mediumsolidprimarytextOnly}>
                  <div className={styles.mastermediumtext}>
                    <div className={styles.content}>
                      <img
                        className={styles.iconContainer}
                        alt=""
                        src="/icon-container.svg"
                      />
                      <div className={styles.apply}>Apply</div>
                      <img
                        className={styles.iconContainer}
                        alt=""
                        src="/icon-container.svg"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className={styles.groupInner} />
          </div>
        </div>
      </div>
      <Button className={styles.xSmalloutlinemodeSuccessi} type="default">
        Product Complaint Dashboard
      </Button>
    </div>
  );
};

export default ProductComplaints;
